<?php
/**
 * Created by PhpStorm.
 * User: Vlada
 * Date: 5/25/2016
 * Time: 6:21 PM
 */
class Admin_model extends CI_Model
{

    public function __construct()
    {
        $this->load->database();
    }
}